package by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types;

public enum StayDuration {
	ONE_DAY(1),
	THREE_DAYS(3),
	FIVE_DAYS(5),
	WEEK(7),
	TWO_WEEKS(14),
	MONTH(30);
	
	private int number;
	
	private StayDuration(int number) {
		this.number = number;
	}

	public int getNumber() {
		return this.number;
	}
	
	public static StayDuration getValue(int number) {
		for (StayDuration value : values()) {
			if (value.getNumber() == number) {
				return value;
			}
		}

		throw new IllegalArgumentException("Invalid days number: " + number);
	}
}
