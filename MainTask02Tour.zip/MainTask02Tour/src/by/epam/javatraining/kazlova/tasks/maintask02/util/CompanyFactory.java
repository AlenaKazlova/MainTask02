package by.epam.javatraining.kazlova.tasks.maintask02.util;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction.BaseTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.container.TourCompany;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl.SeaTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl.ShoppingTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl.TravelTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.MealType;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.StayDuration;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.TransferType;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CompanyFactory {

	public static List<TourCompany> createCompanies() {
		TourCompany company1 = new TourCompany("Sea Tours Company");
		company1.setTours(TourFactory.createSeaTours());

		TourCompany company2 = new TourCompany("Travel and Shopping Company");
		company2.setTours(TourFactory.createTravelTours());
		company2.getTours().addAll(TourFactory.createShoppingTours());

		List<TourCompany> companies = new ArrayList<>();
		companies.add(company1);
		companies.add(company2);

		return companies;
	}
}
