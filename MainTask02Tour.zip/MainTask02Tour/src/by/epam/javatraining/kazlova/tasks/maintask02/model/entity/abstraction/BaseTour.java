package by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.MealType;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.StayDuration;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.TransferType;


/* The abstraction of the Tour/
 * 
 */
public class BaseTour {
	private double price;
	private StayDuration durationDays;
	private MealType meal;
	private TransferType transfer;

	// constructor without parameters or default constructor
	public BaseTour() {
	};

	// constructor with parameters
	public BaseTour(double price, StayDuration durationDays, MealType meal, TransferType transfer) {
		this.price = price;
		this.durationDays = durationDays;
		this.meal = meal;
		this.transfer = transfer;
	}

	// copy constructor
	public BaseTour(BaseTour tour) {
		if (tour == null) {
			throw new IllegalArgumentException("Tour to copy from can not be null");
		}
		this.durationDays = tour.getDurationDays();
		this.meal = tour.getMeal();
		this.price = tour.getPrice();
		this.transfer = tour.getTransfer();
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getPrice() {
		return price;
	}

	public void setDurationDays(StayDuration durationDays) {
		this.durationDays = durationDays;
	}

	public StayDuration getDurationDays() {
		return durationDays;
	}

	public void setMeal(MealType meal) {
		this.meal = meal;
	}

	public MealType getMeal() {
		return meal;
	}

	public void setTransfer(TransferType transfer) {
		if (transfer == null) {
			throw new IllegalArgumentException("Transfer must not be null");
		}
		this.transfer = transfer;
	}

	public TransferType getTransfer() {
		return transfer;
	}

	@Override
	 public String toString() {
	  return "Base tour info: Price: " + this.price +
	    "; Meal: " + this.meal +
	    "; Duration: " + this.durationDays + 
	    "; Transfer: " + this.transfer;
	 }
	
	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}

		if (that == null) {
			return false;
		}

		if (!(that instanceof BaseTour)) {
			return false;
		}

		BaseTour otherTour = (BaseTour) that;

		if (!this.transfer.equals(otherTour.getTransfer())) {
			return false;
		}

		if (!this.meal.equals(otherTour.getMeal())) {
			return false;
		}

		if (this.durationDays != otherTour.getDurationDays()) {
			return false;
		}

		return true;
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 31 * hash + this.durationDays.hashCode(); 
		hash = 31 * hash + this.meal.hashCode();
		hash = 31 * hash + this.transfer.hashCode();
		return hash;
	}
}
