package by.epam.javatraining.kazlova.tasks.maintask02.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction.BaseTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl.SeaTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl.ShoppingTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl.TravelTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.MealType;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.StayDuration;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.TransferType;

public class TourFactory {
	
	public static Set<BaseTour> createSeaTours() {
		Set<BaseTour> tours = new HashSet<>();
		tours.add(new SeaTour(649.53, StayDuration.FIVE_DAYS, MealType.BREAKFAST, TransferType.BUS, "Savona-IsleAruba", 5));
		tours.add(new SeaTour(789.19, StayDuration.WEEK, MealType.BREAKFAST_DINNER, TransferType.PLANE,
				"Marseille-IsleMartinique", 6));
		tours.add(new SeaTour(1000.5, StayDuration.TWO_WEEKS, MealType.ALL_INCLUSIVE, TransferType.BUS_PLANE,
				"Sydney-Benoa", 7));
		tours.add(new SeaTour(1240.0, StayDuration.WEEK, MealType.ALL_INCLUSIVE, TransferType.PLANE,
				"RiodeJaneiro-PuertoMadryn", 9));
		tours.add(new SeaTour(300.5, StayDuration.FIVE_DAYS, MealType.BREAKFAST_DINNER, TransferType.PLANE,
				"Singapore-Phuket", 2));
		return tours;
	}
	
    public static Set<BaseTour> createTravelTours() {
		Set<BaseTour> tours = new HashSet<>();
		tours.add(new TravelTour(100.0, StayDuration.THREE_DAYS, MealType.NONE, TransferType.BUS, "Minks-Moscow-Minsk"));
		tours.add(new TravelTour(300.5, StayDuration.THREE_DAYS, MealType.BREAKFAST_DINNER, TransferType.PLANE, "Minsk-Lviv-Minsk"));
		tours.add(new TravelTour(560., StayDuration.FIVE_DAYS, MealType.ALL_INCLUSIVE, TransferType.BUS_PLANE, "Minsk-London-Minsk"));
		tours.add(new TravelTour(845.5, StayDuration.THREE_DAYS, MealType.BREAKFAST_DINNER, TransferType.PLANE, "Minsk-Paris-Minsk"));
		tours.add(new TravelTour(1000.0, StayDuration.WEEK, MealType.ALL_INCLUSIVE, TransferType.BUS_PLANE, "AbuDhabi"));
		return tours;
	}
    
    public static Set<BaseTour> createShoppingTours() {
		Set<BaseTour> tours = new HashSet<>();
		tours.add(new ShoppingTour(100.0, StayDuration.THREE_DAYS, MealType.NONE, TransferType.BUS, 105));
		tours.add(new ShoppingTour(50.5, StayDuration.THREE_DAYS, MealType.NONE, TransferType.MINIBUS, 55));
		tours.add(new ShoppingTour(150.5, StayDuration.ONE_DAY, MealType.NONE, TransferType.MINIBUS, 55));
		tours.add(new ShoppingTour(100.5, StayDuration.THREE_DAYS, MealType.NONE, TransferType.BUS, 55));
		tours.add(new ShoppingTour(100.5, StayDuration.THREE_DAYS, MealType.BREAKFAST, TransferType.MINIBUS, 55));
		return tours;
	}
	
}
