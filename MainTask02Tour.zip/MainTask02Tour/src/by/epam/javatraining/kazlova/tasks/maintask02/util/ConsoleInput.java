package by.epam.javatraining.kazlova.tasks.maintask02.util;

import java.util.Scanner;

import org.apache.log4j.Logger;

public class ConsoleInput implements Input {
	
	private static final Logger LOG = Logger.getLogger(ConsoleInput.class);
	
	private Scanner scan = new Scanner(System.in);
	
	public int readInt() {
		int input = Integer.parseInt(scan.next());
		LOG.info("User entered integer value: " + input);
		return input;
	}
	
	
		public String readString() {
			String input = scan.next();
			LOG.info("User entered string value: " + input);
			return input; 
		}
		
		
		public String readLine() {
			String input = scan.nextLine();
			LOG.info("User entered string value: " + input);
			return input; 
		}
	
}
