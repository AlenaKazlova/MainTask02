package by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction.BaseTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.MealType;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.StayDuration;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.TransferType;

public class ShoppingTour extends BaseTour {
	private int baggageLimitKg;

	public void setBaggageLimitKg(int baggageLimitKg) {
		this.baggageLimitKg = baggageLimitKg;
	}

	public int getBaggageLimitKg() {
		return baggageLimitKg;
	}

	public ShoppingTour() {

	}

	public ShoppingTour(double price, StayDuration durationDays, MealType meal, TransferType transfer, int baggageLimitKg) {
		super(price, durationDays, meal, transfer);
		this.baggageLimitKg = baggageLimitKg;
	}

	public ShoppingTour(ShoppingTour tour) {
		super(tour);
		this.baggageLimitKg = tour.getBaggageLimitKg();
	}

	@Override
	public String toString() {
		return "Shopping tour has baggage limit " + baggageLimitKg + " in kg . " + super.toString();
	}

	@Override
	public boolean equals(Object that) {
		if (!super.equals(that)) {
			return false;
		}

		if (!(that instanceof ShoppingTour)) {
			return false;
		}

		ShoppingTour otherTour = (ShoppingTour) that;

		return this.baggageLimitKg == otherTour.getBaggageLimitKg();
	}
	
	@Override
	public int hashCode() {
		return 31 * super.hashCode() + baggageLimitKg;
	}
}
