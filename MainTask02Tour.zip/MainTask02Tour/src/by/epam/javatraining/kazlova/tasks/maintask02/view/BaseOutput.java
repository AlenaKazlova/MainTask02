package by.epam.javatraining.kazlova.tasks.maintask02.view;

//abstraction for output
public abstract class BaseOutput {
	public abstract void print(String str) throws Exception;
}