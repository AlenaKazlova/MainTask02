package by.epam.javatraining.kazlova.tasks.maintask02.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction.BaseTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.container.TourCompany;
import by.epam.javatraining.kazlova.tasks.maintask02.model.logic.ToursSorter;

public class ResultUtils {

	public static String getStringRepresentation(Map<String, List<BaseTour>> companyTours) {
		StringBuilder resultBuilder = new StringBuilder("The following companies have tours with selected parameters: \n");
		for (String company : companyTours.keySet()) {
			resultBuilder.append(company).append(":\n");
			for (BaseTour tour : companyTours.get(company)) {
				resultBuilder.append(tour.toString()).append("\n");
			}
			resultBuilder.append("\n");
		}
		
		return resultBuilder.toString();
	}
}
