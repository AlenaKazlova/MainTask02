package by.epam.javatraining.kazlova.tasks.maintask02.model.logic;

import java.util.Comparator;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction.BaseTour;

public class TourComparator implements Comparator<BaseTour> {

	    public int compare(BaseTour a, BaseTour b){
	      
	        if(a.getPrice()> b.getPrice())
	            return 1;
	        else if(a.getPrice()< b.getPrice())
	            return -1;
	        else
	            return 0;
	    }

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// public int compare( BaseTour a, BaseTour b){
	//
	// return a.getPrice().compareTo(b.getPrice());
	// }
//	public int compare(BaseTour a, BaseTour b) {
//
//		return a.getTransfer().compareTo(b.getTransfer());
//	}
//
//	public int compare(BaseTour a, BaseTour b) {
//
//		return a.getTransfer().compareTo(b.getTransfer());
//	}
//
//	public int compare(BaseTour a, BaseTour b) {
//
//		return a.getMeal().compareTo(b.getMeal());
//	}

}
