package by.epam.javatraining.kazlova.tasks.maintask02.model.exceptions;
//what needs to be taken into account ???
public class MainTask02TechnicalException extends Exception {

	public MainTask02TechnicalException() {
		super("Technical Exception with MainTask02");
	}

	public MainTask02TechnicalException(String str, Throwable cause) {
		super(str, cause);
	}
}