package by.epam.javatraining.kazlova.tasks.maintask02.util;

public interface Input {
	int readInt();
    String readString();
    String readLine();
}
