package by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types;

public enum TransferType {
	PLANE,
	BUS,
	MINIBUS,
	TRAIN,
	BUS_PLANE
}
