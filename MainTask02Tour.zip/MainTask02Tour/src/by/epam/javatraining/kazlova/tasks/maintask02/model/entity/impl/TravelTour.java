package by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction.BaseTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.MealType;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.StayDuration;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.TransferType;

public class TravelTour extends BaseTour {

	private String route;

	public TravelTour() {

	}

	public TravelTour(double price, StayDuration durationDays, MealType meal, TransferType transfer, String route) {
		super(price, durationDays, meal, transfer);
		this.route = route;

	}

	public TravelTour(TravelTour tour) {
		super(tour);
		this.route = tour.getRoute();
	}

	public String getRoute() {
		return route;
	}

	public void setRoute(String route) {
		if (route == null || route.isEmpty()) {
			throw new IllegalArgumentException();
		}
		this.route = route;
	}

	@Override
	public String toString() {
		return "Travel tour with " + route + " route . " + super.toString();
	}

	@Override
	public boolean equals(Object that) {
		if (!super.equals(that)) {
			return false;
		}

		if (!(that instanceof TravelTour)) {
			return false;
		}

		TravelTour otherTour = (TravelTour) that;

		return this.route.equalsIgnoreCase(otherTour.getRoute());
	}
	@Override
	public int hashCode() {
		int hash = 31 * super.hashCode();
		if (route != null ) {
			hash += route.hashCode();
		}
		return hash;
	}
}
