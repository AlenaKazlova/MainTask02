package by.epam.javatraining.kazlova.tasks.maintask02.model.logic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction.BaseTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.container.TourCompany;

public class TourFinder {
	
	private static final Logger LOG = Logger.getLogger(TourFinder.class);
	
	public static Map<String, List<BaseTour>> findTours(List<TourCompany> companies, BaseTour tourToLookFor) {
		Map<String, List<BaseTour>> companyTours = new HashMap<>();
		
		for (TourCompany company : companies) {
			if (company.getTours().contains(tourToLookFor)) {
				List<BaseTour> tours = new ArrayList<>();
				LOG.info("The tour is found in " + company.getName());
				for (BaseTour tour : company.getTours()) {
					if (tour.equals(tourToLookFor)) {
					    tours.add(tour);
					}
				}
				companyTours.put(company.getName(), tours);
		    }
	    }

		return companyTours;
    }
}
