package by.epam.javatraining.kazlova.tasks.maintask02.util;

public class FileInput {

}
