package by.epam.javatraining.kazlova.tasks.maintask02.view;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import by.epam.javatraining.kazlova.tasks.maintask02.model.exceptions.MainTask02TechnicalException;

public class FileOutput extends BaseOutput {

	public static final String fileName = "./output/result.txt";

	@Override
	public void print(String str) throws MainTask02TechnicalException {
		File file = new File(fileName);

		try {

			if (!file.exists()) {
				file.createNewFile();
			}

			PrintWriter out = new PrintWriter(file.getAbsoluteFile());

			try {
				out.print(str);
			} finally {
				out.close();
			}
		} catch (IOException e) {
			throw new MainTask02TechnicalException("Failed to write to the file: ", e);
		}
	}
}
