package by.epam.javatraining.kazlova.tasks.maintask02.controller;
/* Alena Kazlova
 * 
 * Development date: 22.11.2018
 * 
 * Java training Main Task 02
 * 
 * ver 1.0
 * 
 * The solutions for the main task 02.
 * (Tourist trips). Form a set of sentences
 * client of choice travel packages of various types for optimal selection. 
 * Consider the choice of transport, food and the number of days. 
 * Implement the selection and sorting of vouchers
 */

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction.BaseTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.container.TourCompany;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.MealType;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.StayDuration;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.TransferType;
import by.epam.javatraining.kazlova.tasks.maintask02.model.logic.TourFinder;
import by.epam.javatraining.kazlova.tasks.maintask02.model.logic.ToursSorter;
import by.epam.javatraining.kazlova.tasks.maintask02.util.CompanyFactory;
import by.epam.javatraining.kazlova.tasks.maintask02.util.ConsoleInput;
import by.epam.javatraining.kazlova.tasks.maintask02.util.Input;
import by.epam.javatraining.kazlova.tasks.maintask02.util.ResultUtils;
import by.epam.javatraining.kazlova.tasks.maintask02.util.TourCreator;
import by.epam.javatraining.kazlova.tasks.maintask02.view.BaseOutput;
import by.epam.javatraining.kazlova.tasks.maintask02.view.FileOutput;
import by.epam.javatraining.kazlova.tasks.maintask02.view.PrinterCreator;

public class Controller {

	private static final Logger LOG = Logger.getLogger(Controller.class);

	public static void main(String[] args) {
		List<TourCompany> companies = CompanyFactory.createCompanies();

		BaseOutput consoleOutput = PrinterCreator.create(2);
		Input consoleInput = new ConsoleInput();

		// Create a tour with required properties
		BaseTour tourToLookFor;
		try {
			consoleOutput.print("Enter the following values: \n" + "Tour type: travel, shopping or cruise \n");
			String tourType = consoleInput.readString();
			tourToLookFor = TourCreator.createTourByType(tourType);

			consoleOutput.print(TourCreator.getTourSpecificFieldName(tourType) + ":\n");
			String tourSpecificValue = consoleInput.readString();
			tourToLookFor = TourCreator.setTourSpecificField(tourToLookFor, tourSpecificValue);

			consoleOutput.print("Stay duration: 1, 3, 5, 7, 14 or 30 days \n");
			int stayDays = consoleInput.readInt();
			StayDuration duration = StayDuration.getValue(stayDays);
			tourToLookFor.setDurationDays(duration);

			consoleOutput.print("Transfer: " + TransferType.PLANE.name() + ", " + TransferType.BUS.name() + ", "
					+ TransferType.MINIBUS.name() + ", " + TransferType.BUS_PLANE.name() + ", "
					+ TransferType.TRAIN.name() + "\n");
			String transferType = consoleInput.readString();
			TransferType transfer = TransferType.valueOf(transferType);
			tourToLookFor.setTransfer(transfer);

			consoleOutput.print("Meal: " + MealType.BREAKFAST.name() + ", " + MealType.BREAKFAST_DINNER.name() + ", "
					+ MealType.ALL_INCLUSIVE.name() + ", " + MealType.NONE.name() + "\n");
			String mealType = consoleInput.readString();
			MealType meal = MealType.valueOf(mealType);
			tourToLookFor.setMeal(meal);

		} catch (Exception e) {
			LOG.error("Unable to print/read the message to/from console: ", e);
			return;
		}

		Map<String, List<BaseTour>> companyTours = TourFinder.findTours(companies, tourToLookFor);
		for (String company : companyTours.keySet()) {
			ToursSorter.sortTours(companyTours.get(company));
		}

		BaseOutput fileOutput = PrinterCreator.create(1);
		try {
			fileOutput.print(ResultUtils.getStringRepresentation(companyTours));
		} catch (Exception e) {
			LOG.error("Unable to write into file: ", e);
			return;
		}

		try {
			consoleOutput.print("Check out the results in output/result.txt file");
		} catch (Exception e) {
			LOG.error("Unable to print the message to console: ", e);
		}

		return;
	}
}
