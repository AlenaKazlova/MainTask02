package by.epam.javatraining.kazlova.tasks.maintask02.util;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction.BaseTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl.SeaTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl.ShoppingTour;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl.TravelTour;

public class TourCreator {

	public static BaseTour createTourByType(String type) {
		BaseTour tour;
		switch(type) {
		case "shopping":
			tour = new ShoppingTour();
			break;
		case "cruise":
			tour = new SeaTour();
			break;
		case "travel":
		default:
			tour = new TravelTour();
			break;
		}
		return tour;
	}
	
	public static String getTourSpecificFieldName(String type) {
		switch(type) {
		case "shopping":
			return "Baggage weight";
		case "cruise":
			return "Number of stops, route";
		case "travel":
		default:
			return "Route";
		}
	}
	
    public static BaseTour setTourSpecificField(BaseTour tour, String userInput) {
		if (tour instanceof ShoppingTour) {
			ShoppingTour shoppingTour = (ShoppingTour)tour;
			shoppingTour.setBaggageLimitKg(Integer.parseInt(userInput));
			return shoppingTour;
		} else if (tour instanceof SeaTour) {
			SeaTour seaTour = (SeaTour)tour;
			String[] values = userInput.split(",");
			seaTour.setNumberOfStops(Integer.parseInt(values[0].trim()));
			seaTour.setRoute(values[1].trim());
			return seaTour;
		} else {
			TravelTour travelTour = (TravelTour)tour;
			travelTour.setRoute(userInput);
			return travelTour;
		}
	}
}
