package by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.MealType;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.StayDuration;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.TransferType;

public class SeaTour extends TravelTour {
	private int numberOfStops;


	public SeaTour() {
		  
	}

	public SeaTour(double price, StayDuration durationDays, MealType meal, TransferType transfer, String route, int numberOfStops) {
		super(price, durationDays, meal, transfer, route);
		this.numberOfStops = numberOfStops;
	}

	public SeaTour(SeaTour tour) {
		super(tour);
		this.numberOfStops = tour.getNumberOfStops();
	}
	
	public void setNumberOfStops(int numberOfStops) {
		if (numberOfStops <= 0) {
			throw new IllegalArgumentException("Number of stops must be positive");
		}
		this.numberOfStops = numberOfStops;
	}

	public int getNumberOfStops() {
		return numberOfStops;
	}

	@Override
	public String toString() {
		return "Sea tour with " + numberOfStops + " stops . " + super.toString();
	}

	@Override
	public boolean equals(Object that) {
		if (!super.equals(that)) {
			return false;
		}

		if (!(that instanceof SeaTour)) {
			return false;
		}

		SeaTour otherTour = (SeaTour) that;

		return this.numberOfStops == otherTour.getNumberOfStops();
	}

	@Override
	public int hashCode() {
		return 31 * super.hashCode() + numberOfStops;
	}
	  
}
