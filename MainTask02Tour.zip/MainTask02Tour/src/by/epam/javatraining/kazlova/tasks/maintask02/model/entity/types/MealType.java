package by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types;

public enum MealType {
	NONE,
	BREAKFAST,
	BREAKFAST_DINNER,
	ALL_INCLUSIVE
}
