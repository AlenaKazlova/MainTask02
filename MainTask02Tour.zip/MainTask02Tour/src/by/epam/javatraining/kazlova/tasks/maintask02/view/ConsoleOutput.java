package by.epam.javatraining.kazlova.tasks.maintask02.view;

import org.apache.log4j.Logger;

public class ConsoleOutput extends BaseOutput {
	private static final Logger LOG = Logger.getLogger(ConsoleOutput.class);
	
	@Override
	public void print(String s) {
		LOG.info("Text printed to console: " + s);
		System.out.println(s);
	}
}
