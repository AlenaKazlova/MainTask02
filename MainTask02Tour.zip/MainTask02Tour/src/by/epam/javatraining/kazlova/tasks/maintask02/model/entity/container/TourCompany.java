package by.epam.javatraining.kazlova.tasks.maintask02.model.entity.container;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction.BaseTour;

import java.util.HashSet;
import java.util.Set;

public class TourCompany {
	private String name;
	private Set<BaseTour> tours;

	public TourCompany() {
		this.tours = new HashSet<>();
	}
	
	public TourCompany(String name) {
		this.name = name;
		this.tours = new HashSet<>();
	}
	
	public TourCompany(TourCompany company) {
		this.name = company.getName();
		this.tours = company.getTours();
	}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<BaseTour> getTours() {
        return tours;
    }

    public void setTours(Set<BaseTour> tours) {
        this.tours = tours;
    }
 
    @Override
    public String toString() {
	    return "Tour Company " + this.name;
    }
 
    @Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}

		if (that == null) {
			return false;
		}

		if (!(that instanceof TourCompany)) {
			return false;
		}

		TourCompany otherCompany = (TourCompany) that;

		return this.name.equals(otherCompany.getName());
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 31 * hash + this.name.hashCode();
		return hash;
	}
}