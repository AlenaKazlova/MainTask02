package by.epam.javatraining.kazlova.tasks.maintask02.model.logic;

import java.util.Collections;
import java.util.List;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.abstraction.BaseTour;
public class ToursSorter {

	public static void sortTours(List<BaseTour> tours) {
		Collections.sort(tours, new TourComparator());
	}

}
