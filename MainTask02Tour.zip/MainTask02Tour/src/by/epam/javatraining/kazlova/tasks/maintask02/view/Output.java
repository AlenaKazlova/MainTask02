package by.epam.javatraining.kazlova.tasks.maintask02.view;

import java.io.File;
import java.io.IOException;
//import java.io.PrintWriter;
import org.apache.log4j.Logger;

public abstract class Output {
	protected String s;

	public void setS(String s) {
		this.s = s;
	}

	public String getS() {
		return s;
	}

	abstract public void print(Object obj);
}