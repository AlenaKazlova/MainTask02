package by.epam.javatraining.kazlova.tasks.maintask02.view;

public class PrinterCreator {

	public static BaseOutput create(int type) {
		BaseOutput printer;

		switch (type) {
		case 1:
			printer = new FileOutput();
			break;
		case 2:
			printer = new ConsoleOutput();
			break;
		default:
			printer = new LogOutput();
		}

		return printer;
	}
}

/*
 * switch(OUTPUT) { case 1: ConsoleOutput.print(String str); break; case 2:
 * LogOutput.print(String str); break; case 3: FileOutput.print(String str);
 * break; default: LogOutput.print(String str); } return int; }
 */