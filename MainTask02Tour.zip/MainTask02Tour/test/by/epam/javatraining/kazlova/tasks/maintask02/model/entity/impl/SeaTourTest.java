package by.epam.javatraining.kazlova.tasks.maintask02.model.entity.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.apache.log4j.Logger;
import org.junit.Test;

import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.MealType;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.StayDuration;
import by.epam.javatraining.kazlova.tasks.maintask02.model.entity.types.TransferType;

public class SeaTourTest {
	
	Logger LOG = Logger.getLogger(SeaTourTest.class);
	SeaTour tour1 = new SeaTour(100.0, StayDuration.THREE_DAYS, MealType.NONE, TransferType.BUS, "Minks - Moscow - Minsk", 3);
	
    @Test(expected = IllegalArgumentException.class)
	public void copyConstructorNullArgument() {
    	LOG.info("Running SeaTourTest");
		new SeaTour(null);
	}

    @Test
    public void copyConstructor() {
		SeaTour tour2 = new SeaTour(tour1);
		
		assertEquals(tour1.getDurationDays(), tour2.getDurationDays());
		assertEquals(tour1.getMeal(), tour2.getMeal());
		assertEquals(tour1.getNumberOfStops(), tour2.getNumberOfStops());
		assertEquals(tour1.getRoute(), tour2.getRoute());
		assertEquals(tour1.getTransfer(), tour2.getTransfer());
		assertEquals(new Double(tour1.getPrice()), new Double(tour2.getPrice()));
	}
    
    @Test
    public void equalsSameObject() {
    	assertTrue(tour1.equals(tour1));
    }
    
    @Test
    public void equalsNullParameter() {
    	assertFalse(tour1.equals(null));
    }
    
    @Test
    public void equalsOtherClassInstance() {
    	assertFalse(tour1.equals(new TravelTour(tour1)));
    }
    
    @Test
    public void equalsDifferentFields() {
    	SeaTour tour2 = new SeaTour(tour1);
    	tour2.setNumberOfStops(500);

    	assertFalse(tour1.equals(tour2));
    }
    
    @Test 
    public void equalsEqualObjects() {
    	SeaTour tour2 = new SeaTour(tour1);
    	assertTrue(tour1.equals(tour2));
    	
    	SeaTour tour3 = new SeaTour(tour2);
    	assertTrue(tour2.equals(tour3));
    	assertTrue(tour1.equals(tour3));
    }
    
    @Test
    public void hashCodeValue() {
    	assertEquals(tour1.hashCode(), tour1.hashCode());
    	
    	SeaTour tour2 = new SeaTour(tour1);
    	assertEquals(tour1.hashCode(), tour2.hashCode());
    	
    	tour2.setDurationDays(StayDuration.WEEK);
    	tour2.setRoute("a-b");
    	tour2.setNumberOfStops(12);
    	
    	assertNotEquals(tour1.hashCode(), tour2.hashCode());
    }

    @Test
    public void setDurationDays() {
    	SeaTour tour = new SeaTour();
    	
    	tour.setDurationDays(StayDuration.FIVE_DAYS);
    	assertEquals(StayDuration.FIVE_DAYS, tour.getDurationDays());
    }
    
    @Test
    public void setMeal() {
        SeaTour tour = new SeaTour();
    	
    	tour.setMeal(MealType.BREAKFAST_DINNER);
    	assertEquals(MealType.BREAKFAST_DINNER, tour.getMeal());
    }
    
    @Test
    public void setPrice() {
        SeaTour tour = new SeaTour();
        
        tour.setPrice(105.5);
        assertEquals(new Double(105.5), new Double(tour.getPrice()));
    }

    @Test(expected = IllegalArgumentException.class)
    public void setRouteNullValue() {
        SeaTour tour = new SeaTour();
    	tour.setRoute(null);
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void setRouteEmptyValue() {
        SeaTour tour = new SeaTour();
    	tour.setRoute("");
    }

    @Test
    public void setRoute() {
        SeaTour tour = new SeaTour();
    	
    	tour.setRoute("a-b");
    	assertEquals("a-b", tour.getRoute());
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void setTransferNullArgument() {
        SeaTour tour = new SeaTour();
        tour.setTransfer(null);
    }
    
    @Test
    public void setTransfer() {
        SeaTour tour = new SeaTour();

    	tour.setTransfer(TransferType.MINIBUS);
    	assertEquals(TransferType.MINIBUS, tour.getTransfer());
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void setNumberOfStopsNegativeArgument() {
        SeaTour tour = new SeaTour();
    	tour.setNumberOfStops(-1);
    }
    
    @Test
    public void setNumberOfStops() {
        SeaTour tour = new SeaTour();

        tour.setNumberOfStops(3);
    	assertEquals(3, tour.getNumberOfStops());
    }
}
